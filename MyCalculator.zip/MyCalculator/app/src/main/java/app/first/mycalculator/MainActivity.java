//calculator app by Yan Lu ITP226 10/21
package app.first.mycalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import org.mariuszgromada.math.mxparser.Expression;



public class MainActivity extends AppCompatActivity {
    int[] buttonIds = new int[]{
            R.id.button0,
            R.id.button1,
            R.id.button2,
            R.id.button3,
            R.id.button4,
            R.id.button5,
            R.id.button6,
            R.id.button7,
            R.id.button8,
            R.id.button9,
            R.id.buttonDec,
            R.id.buttonMult,
            R.id.buttonDiv,
            R.id.buttonPlus_Sign,
            R.id.buttonMinus_sign,
            R.id.buttonPower,
            R.id.buttonPCT,
            R.id.buttonLP,
            R.id.buttonRP,
            R.id.buttonDel,
            R.id.buttonClr,
            R.id.buttonEqu
    };

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final TextView calculatorText = findViewById(R.id.Screen);
        final TextView textView = (TextView) findViewById(R.id.textView);

        calculatorText.setSelected(true);
        textView.setSelected(true);

        for (int buttonId : buttonIds) {

            final int id = buttonId;

            final Button button = findViewById(buttonId);

            button.setOnClickListener(new View.OnClickListener() {

                @Override

                public void onClick(View v) {

                    if (id==R.id.buttonEqu) {

                        String request = calculatorText.getText().toString();

                        Expression expression = new Expression(request);

                        double result = expression.calculate();
                        textView.setText(" =" + result);
                    
                    }




else if (id==R.id.buttonClr) {
    calculatorText.setText("");
    textView.setText("");

                    }

else if (id== R.id.buttonDel){
                        String s = calculatorText.getText().toString();
                        s = s.substring(0, s.length() - 1);
                        calculatorText.setText(s);
                                          }

else {

                        String key = button.getText().toString();

                        Log.d("main", "getting key " + key);

                        calculatorText.setText(calculatorText.getText()+key);

                    }

                }

            });

        }


    }

    }
